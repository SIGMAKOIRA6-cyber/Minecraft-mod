package com.basefinder.gui;

import com.basefinder.BaseFinderMod;
import com.basefinder.config.Config;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class GuiScreen extends Screen {
    private final List<ClickableWidget> widgets = new ArrayList<>();
    private int tab = 0;
    private final String[] tabs = {"General", "NewChunks", "StorageESP", "BaseScore", "Tunnels", "SusChunks", "Waypoints", "Signals", "Render", "Colors"};

    public GuiScreen() {
        super(Text.literal("BaseFinder Config"));
    }

    @Override
    protected void init() {
        widgets.clear();
        int y = 40;

        // Tab buttons
        for (int i = 0; i < tabs.length; i++) {
            final int tabIndex = i;
            ButtonWidget btn = ButtonWidget.builder(Text.literal(tabs[i]), b -> {
                tab = tabIndex;
                init();
            }).dimensions(width / 2 - 150 + i * 30, 10, 28, 20).build();
            widgets.add(btn);
        }

        addWidgetsForTab(tab, y);

        widgets.forEach(this::addDrawableChild);
    }

    private void addWidgetsForTab(int tab, int y) {
        Config cfg = BaseFinderMod.config;

        switch (tab) {
            case 0 -> { // General
                addToggle(y, "Enabled", cfg.general.enabled, v -> cfg.general.enabled = v);
                y += 25;
                addSlider(y, "Scan Range", cfg.general.scanRange, 1, 16, v -> cfg.general.scanRange = v);
                y += 25;
                addSlider(y, "Min Y", cfg.general.minY, -64, 320, v -> cfg.general.minY = v);
                y += 25;
                addSlider(y, "Max Y", cfg.general.maxY, -64, 320, v -> cfg.general.maxY = v);
                y += 25;
                addSlider(y, "Sample Rate", cfg.general.sampleRate, 1, 16, v -> cfg.general.sampleRate = v);
                y += 25;
                addSlider(y, "Scan Budget (ms)", cfg.general.scanBudgetMs, 1, 10, v -> cfg.general.scanBudgetMs = v);
            }
            case 1 -> { // NewChunks
                addToggle(y, "Enabled", cfg.newChunks.enabled, v -> cfg.newChunks.enabled = v);
                y += 25;
                addSlider(y, "Outline Width", cfg.newChunks.outlineWidth, 1, 5, v -> cfg.newChunks.outlineWidth = v);
                y += 25;
                addSlider(y, "Outline Alpha", (int)(cfg.newChunks.outlineAlpha * 100), 0, 100, v -> cfg.newChunks.outlineAlpha = v/100f);
                y += 25;
                addColorPicker(y, "Old Gen Color", cfg.newChunks.oldGenColor, v -> cfg.newChunks.oldGenColor = v);
                y += 25;
                addColorPicker(y, "New Gen Color", cfg.newChunks.newGenColor, v -> cfg.newChunks.newGenColor = v);
            }
            case 2 -> { // StorageESP
                addToggle(y, "Enabled", cfg.storageESP.enabled, v -> cfg.storageESP.enabled = v);
                y += 25;
                addSlider(y, "Max Distance", cfg.storageESP.maxDistance, 16, 256, v -> cfg.storageESP.maxDistance = v);
                y += 25;
                addToggle(y, "Show Tracers", cfg.storageESP.showTracers, v -> cfg.storageESP.showTracers = v);
                y += 25;
                for (String type : cfg.storageESP.colors.keySet()) {
                    final String t = type;
                    addColorPicker(y, type.substring(0,1).toUpperCase()+type.substring(1), cfg.storageESP.colors.get(type), v -> cfg.storageESP.colors.put(t, v));
                    y += 25;
                }
            }
            case 3 -> { // BaseScore
                addToggle(y, "Enabled", cfg.baseScore.enabled, v -> cfg.baseScore.enabled = v);
                y += 25;
                addSlider(y, "Threshold", cfg.baseScore.threshold, 1, 100, v -> cfg.baseScore.threshold = v);
                y += 25;
                addSlider(y, "Top Count", cfg.baseScore.topCount, 1, 50, v -> cfg.baseScore.topCount = v);
                y += 25;
                addSlider(y, "Min Non-Natural %", cfg.baseScore.minNonNaturalRatio, 1, 50, v -> cfg.baseScore.minNonNaturalRatio = v);
            }
            case 4 -> { // Tunnels
                addToggle(y, "Enabled", cfg.tunnelDetector.enabled, v -> cfg.tunnelDetector.enabled = v);
                y += 25;
                addSlider(y, "Min Length", cfg.tunnelDetector.minLength, 5, 100, v -> cfg.tunnelDetector.minLength = v);
                y += 25;
                addToggle(y, "Detect Ice Roads", cfg.tunnelDetector.detectIceRoads, v -> cfg.tunnelDetector.detectIceRoads = v);
                y += 25;
                addToggle(y, "Detect Highways", cfg.tunnelDetector.detectHighways, v -> cfg.tunnelDetector.detectHighways = v);
                y += 25;
                addColorPicker(y, "Highlight Color", cfg.tunnelDetector.highlightColor, v -> cfg.tunnelDetector.highlightColor = v);
            }
            case 5 -> { // SusChunks
                addToggle(y, "Enabled", cfg.susChunks.enabled, v -> cfg.susChunks.enabled = v);
                y += 25;
                addSlider(y, "Threshold", cfg.susChunks.threshold, 1, 100, v -> cfg.susChunks.threshold = v);
                y += 25;
                addSlider(y, "Render Distance", cfg.susChunks.renderDistance, 16, 512, v -> cfg.susChunks.renderDistance = v);
                y += 25;
                addToggle(y, "Heatmap Mode", cfg.susChunks.heatMapMode, v -> cfg.susChunks.heatMapMode = v);
                y += 25;
                addSlider(y, "Ignore Spawn Radius", cfg.susChunks.ignoreSpawnRadius, 0, 1000, v -> cfg.susChunks.ignoreSpawnRadius = v);
            }
            case 6 -> { // Waypoints
                addToggle(y, "Enabled", cfg.waypoints.enabled, v -> cfg.waypoints.enabled = v);
                y += 25;
                addToggle(y, "Auto Save", cfg.waypoints.autoSave, v -> cfg.waypoints.autoSave = v);
                y += 25;
                addSlider(y, "HUD X", cfg.waypoints.hudX, 0, width, v -> cfg.waypoints.hudX = v);
                y += 25;
                addSlider(y, "HUD Y", cfg.waypoints.hudY, 0, height, v -> cfg.waypoints.hudY = v);
                y += 25;
                addSlider(y, "Max Waypoints", cfg.waypoints.maxWaypoints, 10, 500, v -> cfg.waypoints.maxWaypoints = v);
            }
            case 7 -> { // Signals
                addSlider(y, "Foreign Blocks", (int)(cfg.signalWeights.foreignBlocks * 10), 0, 50, v -> cfg.signalWeights.foreignBlocks = v/10f);
                y += 25;
                addSlider(y, "Light Anomalies", (int)(cfg.signalWeights.lightAnomalies * 10), 0, 50, v -> cfg.signalWeights.lightAnomalies = v/10f);
                y += 25;
                addSlider(y, "Geometry", (int)(cfg.signalWeights.geometry * 10), 0, 50, v -> cfg.signalWeights.geometry = v/10f);
                y += 25;
                addSlider(y, "Block Entities", (int)(cfg.signalWeights.blockEntities * 10), 0, 50, v -> cfg.signalWeights.blockEntities = v/10f);
                y += 25;
                addSlider(y, "Farms", (int)(cfg.signalWeights.farms * 10), 0, 50, v -> cfg.signalWeights.farms = v/10f);
                y += 25;
                addSlider(y, "Terrain Edits", (int)(cfg.signalWeights.terrainEdits * 10), 0, 50, v -> cfg.signalWeights.terrainEdits = v/10f);
                y += 25;
                addSlider(y, "Entity Clusters", (int)(cfg.signalWeights.entityClusters * 10), 0, 50, v -> cfg.signalWeights.entityClusters = v/10f);
                y += 25;
                addSlider(y, "New Chunk Context", (int)(cfg.signalWeights.newChunkContext * 10), 0, 50, v -> cfg.signalWeights.newChunkContext = v/10f);
            }
            case 8 -> { // Render
                addSlider(y, "Column Height", cfg.render.chunkColumnHeight, 64, 384, v -> cfg.render.chunkColumnHeight = v);
                y += 25;
                addSlider(y, "Column Alpha", (int)(cfg.render.columnAlpha * 100), 0, 100, v -> cfg.render.columnAlpha = v/100f);
                y += 25;
                addSlider(y, "Outline Alpha", (int)(cfg.render.outlineAlpha * 100), 0, 100, v -> cfg.render.outlineAlpha = v/100f);
                y += 25;
                addSlider(y, "Outline Width", cfg.render.outlineWidth, 1, 5, v -> cfg.render.outlineWidth = v);
                y += 25;
                addToggle(y, "Show Scores", cfg.render.showScores, v -> cfg.render.showScores = v);
                y += 25;
                addToggle(y, "Show Signal Names", cfg.render.showSignalNames, v -> cfg.render.showSignalNames = v);
            }
            case 9 -> { // Colors
                addColorPicker(y, "Green", cfg.colors.green, v -> cfg.colors.green = v);
                y += 25;
                addColorPicker(y, "Yellow", cfg.colors.yellow, v -> cfg.colors.yellow = v);
                y += 25;
                addColorPicker(y, "Orange", cfg.colors.orange, v -> cfg.colors.orange = v);
                y += 25;
                addColorPicker(y, "Red", cfg.colors.red, v -> cfg.colors.red = v);
                y += 25;
                addColorPicker(y, "Heatmap Low", cfg.colors.heatmapLow, v -> cfg.colors.heatmapLow = v);
                y += 25;
                addColorPicker(y, "Heatmap High", cfg.colors.heatmapHigh, v -> cfg.colors.heatmapHigh = v);
            }
        }

        // Save button
        ButtonWidget saveBtn = ButtonWidget.builder(Text.literal("Save Config"), b -> {
            cfg.save();
            client.player.sendMessage(Text.literal("§aConfig saved!"), true);
        }).dimensions(width / 2 - 50, height - 30, 100, 20).build();
        widgets.add(saveBtn);
    }

    private void addToggle(int y, String name, boolean value, Consumer<Boolean> callback) {
        ButtonWidget btn = ButtonWidget.builder(
            Text.literal(name + ": " + (value ? "§aON" : "§cOFF")),
            b -> callback.accept(!value)
        ).dimensions(width / 2 - 100, y, 200, 20).build();
        widgets.add(btn);
    }

    private void addSlider(int y, String name, int value, int min, int max, Consumer<Integer> callback) {
        SliderWidget slider = new SliderWidget(width / 2 - 100, y, 200, 20,
            Text.literal(name + ": " + value), (float)(value - min) / (max - min)) {
            @Override
            protected void applyValue() {
                int val = Math.round(min + value * (max - min));
                setMessage(Text.literal(name + ": " + val));
                callback.accept(val);
            }
        };
        widgets.add(slider);
    }

    private void addColorPicker(int y, String name, int color, Consumer<Integer> callback) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        int a = (color >> 24) & 0xFF;

        ButtonWidget btn = ButtonWidget.builder(
            Text.literal(name + ": #" + String.format("%06X", color & 0xFFFFFF)),
            b -> {
                int newColor = (a << 24) | ((r + 50) % 256 << 16) | ((g + 50) % 256 << 8) | ((b + 50) % 256);
                callback.accept(newColor);
                init();
            }
        ).dimensions(width / 2 - 100, y, 200, 20).build();
        widgets.add(btn);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        super.render(context, mouseX, mouseY, delta);

        // Title
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 5, 0xFFFFFF);

        // Tab highlight
        if (tab >= 0 && tab < tabs.length) {
            int tx = width / 2 - 150 + tab * 30;
            context.fill(tx, 10, tx + 28, 30, 0x80FFFFFF);
        }
    }

    @Override
    public void close() {
        BaseFinderMod.config.save();
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}