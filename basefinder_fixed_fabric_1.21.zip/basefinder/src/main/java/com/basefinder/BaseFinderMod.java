package com.basefinder;

import com.basefinder.config.Config;
import com.basefinder.modules.*;
import com.basefinder.render.Renderer;
import com.basefinder.scan.ChunkScanner;
import com.basefinder.util.WaypointManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class BaseFinderMod implements ClientModInitializer {
    public static final String MOD_ID = "basefinder";
    public static Config config;
    public static ChunkScanner scanner;
    public static Renderer renderer;
    public static WaypointManager waypointManager;
    public static ModuleManager moduleManager;

    public static KeyBinding openGuiKey;
    public static KeyBinding toggleModKey;

    @Override
    public void onInitializeClient() {
        config = Config.load();
        scanner = new ChunkScanner();
        renderer = new Renderer();
        waypointManager = new WaypointManager();
        moduleManager = new ModuleManager();

        registerKeybindings();
        registerEvents();
        waypointManager.load();
    }

    private void registerKeybindings() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.basefinder.open_gui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.basefinder.general"
        ));

        toggleModKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.basefinder.toggle",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_B,
            "category.basefinder.general"
        ));
    }

    private void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new com.basefinder.gui.GuiScreen());
                }
            }

            if (toggleModKey.wasPressed()) {
                config.general.enabled = !config.general.enabled;
                if (client.player != null) {
                    client.player.sendMessage(Text.literal("§aBaseFinder " + (config.general.enabled ? "enabled" : "disabled")), true);
                }
                config.save();
            }

            if (config.general.enabled) {
                scanner.onTick();
                moduleManager.onTick();
            }
        });

        WorldRenderEvents.LAST.register(context -> {
            if (config.general.enabled && client != null && client.world != null) {
                renderer.render(context);
            }
        });
    }

    public static MinecraftClient getClient() {
        return MinecraftClient.getInstance();
    }
}