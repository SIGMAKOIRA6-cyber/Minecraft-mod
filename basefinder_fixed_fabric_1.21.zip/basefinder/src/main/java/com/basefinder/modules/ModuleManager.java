package com.basefinder.modules;

import com.basefinder.BaseFinderMod;
import com.basefinder.config.Config;
import com.basefinder.scan.ScanResult;
import com.basefinder.util.Vec3i;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ModuleManager {
    public final NewChunksModule newChunks = new NewChunksModule();
    public final StorageESPModule storageESP = new StorageESPModule();
    public final BaseScoreModule baseScore = new BaseScoreModule();
    public final TunnelDetectorModule tunnelDetector = new TunnelDetectorModule();
    public final WaypointsModule waypoints = new WaypointsModule();
    public final SusChunksModule susChunks = new SusChunksModule();

    private final List<Module> modules = List.of(newChunks, storageESP, baseScore, tunnelDetector, waypoints, susChunks);
    private final Map<ChunkPos, ScanResult> scanCache = new ConcurrentHashMap<>();
    private final Set<ChunkPos> pendingScans = ConcurrentHashMap.newKeySet();

    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    public ScanResult getOrScanChunk(ChunkPos pos) {
        ScanResult cached = scanCache.get(pos);
        if (cached != null && !cached.isStale()) return cached;

        pendingScans.add(pos);
        return null;
    }

    public void putScanResult(ChunkPos pos, ScanResult result) {
        scanCache.put(pos, result);
        pendingScans.remove(pos);

        for (Module m : modules) {
            if (m.isEnabled()) m.onChunkScanned(pos, result);
        }
    }

    public void invalidateChunk(ChunkPos pos) {
        scanCache.remove(pos);
    }

    public void clearCache() {
        scanCache.clear();
    }

    public interface Module {
        boolean isEnabled();
        void onTick();
        void onChunkScanned(ChunkPos pos, ScanResult result);
        default String getName() { return getClass().getSimpleName(); }
    }

    public static class NewChunksModule implements Module {
        private final Map<ChunkPos, ChunkState> chunkStates = new ConcurrentHashMap<>();

        @Override public boolean isEnabled() { return BaseFinderMod.config.newChunks.enabled; }

        @Override public void onTick() {}

        @Override public void onChunkScanned(ChunkPos pos, ScanResult result) {
            ChunkState state = analyzeChunk(result);
            chunkStates.put(pos, state);
        }

        public ChunkState getState(ChunkPos pos) {
            return chunkStates.get(pos);
        }

        private ChunkState analyzeChunk(ScanResult result) {
            int oldGenBlocks = 0, newGenBlocks = 0;
            for (BlockState state : result.blockStates.values()) {
                if (isOldGenerationBlock(state.getBlock())) oldGenBlocks++;
                else if (isNewGenerationBlock(state.getBlock())) newGenBlocks++;
            }
            return new ChunkState(oldGenBlocks > newGenBlocks * 2);
        }

        private boolean isOldGenerationBlock(Block block) {
            return block == Blocks.COBBLESTONE || block == Blocks.STONE_BRICKS ||
                   block == Blocks.MOSSY_COBBLESTONE || block == Blocks.MOSSY_STONE_BRICKS ||
                   block == Blocks.NETHER_BRICKS || block == Blocks.NETHERRACK ||
                   block == Blocks.END_STONE || block == Blocks.PURPUR_BLOCK;
        }

        private boolean isNewGenerationBlock(Block block) {
            return block == Blocks.DIRT || block == Blocks.GRASS_BLOCK ||
                   block == Blocks.STONE || block == Blocks.DEEPSLATE ||
                   block == Blocks.SAND || block == Blocks.GRAVEL;
        }

        public record ChunkState(boolean isOldGeneration) {}
    }

    public static class StorageESPModule implements Module {
        private final Map<ChunkPos, List<StorageInfo>> storageCache = new ConcurrentHashMap<>();

        @Override public boolean isEnabled() { return BaseFinderMod.config.storageESP.enabled; }

        @Override public void onTick() {}

        @Override public void onChunkScanned(ChunkPos pos, ScanResult result) {
            List<StorageInfo> storages = new ArrayList<>();
            for (var entry : result.blockEntities.entrySet()) {
                BlockEntity be = entry.getValue();
                StorageType type = getStorageType(be);
                if (type != null) {
                    storages.add(new StorageInfo(entry.getKey(), type, be));
                }
            }
            if (!storages.isEmpty()) storageCache.put(pos, storages);
            else storageCache.remove(pos);
        }

        public List<StorageInfo> getStorages(ChunkPos pos) {
            return storageCache.get(pos);
        }

        private StorageType getStorageType(BlockEntity be) {
            return switch (be.getType()) {
                case CHEST -> StorageType.CHEST;
                case BARREL -> StorageType.BARREL;
                case SHULKER_BOX -> StorageType.SHULKER;
                case FURNACE, BLAST_FURNACE, SMOKER -> StorageType.FURNACE;
                case HOPPER -> StorageType.HOPPER;
                case MOB_SPAWNER -> StorageType.SPAWNER;
                default -> null;
            };
        }

        public enum StorageType { CHEST, BARREL, SHULKER, FURNACE, HOPPER, SPAWNER }

        public record StorageInfo(BlockPos pos, StorageType type, BlockEntity entity) {}
    }

    public static class BaseScoreModule implements Module {
        private final Map<ChunkPos, BaseScore> scores = new ConcurrentHashMap<>();

        @Override public boolean isEnabled() { return BaseFinderMod.config.baseScore.enabled; }

        @Override public void onTick() {}

        @Override public void onChunkScanned(ChunkPos pos, ScanResult result) {
            int score = calculateScore(result);
            if (score >= BaseFinderMod.config.baseScore.threshold) {
                scores.put(pos, new BaseScore(score, getTopSignals(result)));
            } else {
                scores.remove(pos);
            }
        }

        public BaseScore getScore(ChunkPos pos) {
            return scores.get(pos);
        }

        public List<BaseScore> getTopScores(int count) {
            return scores.entrySet().stream()
                .sorted(Map.Entry.<ChunkPos, BaseScore>comparingByValue((a, b) -> Integer.compare(b.score, a.score)))
                .limit(count)
                .map(e -> new BaseScore(e.getValue().score, e.getValue().topSignals, e.getKey()))
                .toList();
        }

        private int calculateScore(ScanResult result) {
            int nonNatural = 0, total = 0, storage = 0, beds = 0, signs = 0, redstone = 0;

            for (BlockState state : result.blockStates.values()) {
                total++;
                Block block = state.getBlock();
                if (isPlayerPlaced(block)) nonNatural++;
                if (isStorage(block)) storage++;
                if (block == Blocks.BEDROCK || block.getName().getString().contains("bed")) beds++;
                if (block.getName().getString().contains("sign") || block.getName().getString().contains("banner")) signs++;
                if (isRedstoneComponent(block)) redstone++;
            }

            if (total == 0) return 0;
            int density = (nonNatural * 100) / total;
            return density + storage * 5 + beds * 3 + signs * 2 + redstone * 2;
        }

        private List<String> getTopSignals(ScanResult result) {
            List<String> signals = new ArrayList<>();
            if (result.hasStorage) signals.add("Storage");
            if (result.hasBeds) signals.add("Beds");
            if (result.hasSigns) signals.add("Signs");
            if (result.hasRedstone) signals.add("Redstone");
            if (result.nonNaturalRatio > 30) signals.add("Non-natural blocks");
            return signals;
        }

        private boolean isPlayerPlaced(Block block) {
            return block == Blocks.COBBLESTONE || block == Blocks.STONE_BRICKS ||
                   block == Blocks.PLANKS || block == Blocks.GLASS ||
                   block == Blocks.CONCRETE || block == Blocks.WOOL ||
                   block == Blocks.OBSIDIAN || block == Blocks.BRICKS ||
                   block == Blocks.NETHER_BRICKS || block == Blocks.QUARTZ_BLOCK;
        }

        private boolean isStorage(Block block) {
            return block == Blocks.CHEST || block == Blocks.BARREL ||
                   block == Blocks.SHULKER_BOX || block == Blocks.FURNACE ||
                   block == Blocks.HOPPER;
        }

        private boolean isRedstoneComponent(Block block) {
            return block == Blocks.REDSTONE_WIRE || block == Blocks.REDSTONE_BLOCK ||
                   block == Blocks.REPEATER || block == Blocks.COMPARATOR ||
                   block == Blocks.OBSERVER || block == Blocks.PISTON ||
                   block == Blocks.DISPENSER || block == Blocks.DROPPER;
        }

        public record BaseScore(int score, List<String> topSignals, ChunkPos pos) {
            public BaseScore(int score, List<String> topSignals) {
                this(score, topSignals, null);
            }
        }
    }

    public static class TunnelDetectorModule implements Module {
        private final Map<ChunkPos, List<Tunnel>> tunnels = new ConcurrentHashMap<>();

        @Override public boolean isEnabled() { return BaseFinderMod.config.tunnelDetector.enabled; }

        @Override public void onTick() {}

        @Override public void onChunkScanned(ChunkPos pos, ScanResult result) {
            List<Tunnel> found = detectTunnels(result);
            if (!found.isEmpty()) tunnels.put(pos, found);
            else tunnels.remove(pos);
        }

        public List<Tunnel> getTunnels(ChunkPos pos) {
            return tunnels.get(pos);
        }

        private List<Tunnel> detectTunnels(ScanResult result) {
            List<Tunnel> found = new ArrayList<>();
            Map<BlockPos, BlockState> blocks = result.blockStates;

            for (int x = 0; x < 16; x++) {
                for (int z = 0; z < 16; z++) {
                    for (int y = result.minY; y <= result.maxY; y++) {
                        BlockPos pos = new BlockPos(x, y, z);
                        BlockState state = blocks.get(pos);
                        if (state == null || !state.isAir()) continue;

                        checkDirection(blocks, pos, 1, 0, 0, found, "X");
                        checkDirection(blocks, pos, 0, 0, 1, found, "Z");
                        checkDirection(blocks, pos, 0, 1, 0, found, "Y");
                    }
                }
            }
            return found;
        }

        private void checkDirection(Map<BlockPos, BlockState> blocks, BlockPos start, int dx, int dy, int dz,
                                   List<Tunnel> found, String dir) {
            int len = 0;
            BlockPos.Mutable pos = new BlockPos.Mutable(start);
            while (true) {
                pos.move(dx, dy, dz);
                BlockState state = blocks.get(pos);
                if (state == null || !state.isAir()) break;
                len++;
                if (len >= BaseFinderMod.config.tunnelDetector.minLength) {
                    found.add(new Tunnel(start, pos, dir, len));
                    break;
                }
            }
        }

        public record Tunnel(BlockPos start, BlockPos end, String direction, int length) {}
    }

    public static class WaypointsModule implements Module {
        @Override public boolean isEnabled() { return BaseFinderMod.config.waypoints.enabled; }

        @Override public void onTick() {}

        @Override public void onChunkScanned(ChunkPos pos, ScanResult result) {}
    }

    public static class SusChunksModule implements Module {
        private final Map<ChunkPos, SusScore> susCache = new ConcurrentHashMap<>();

        @Override public boolean isEnabled() { return BaseFinderMod.config.susChunks.enabled; }

        @Override public void onTick() {}

        @Override public void onChunkScanned(ChunkPos pos, ScanResult result) {
            if (isNearSpawn(pos)) return;
            if (isKnownStructure(result)) return;

            SusScore score = calculateSusScore(pos, result);
            if (score.total >= BaseFinderMod.config.susChunks.threshold) {
                susCache.put(pos, score);
            } else {
                susCache.remove(pos);
            }
        }

        public SusScore getSusScore(ChunkPos pos) {
            return susCache.get(pos);
        }

        public List<SusScore> getTopSus(int count) {
            return susCache.entrySet().stream()
                .sorted(Map.Entry.<ChunkPos, SusScore>comparingByValue((a, b) -> Float.compare(b.total, a.total)))
                .limit(count)
                .map(e -> new SusScore(e.getValue(), e.getKey()))
                .toList();
        }

        private boolean isNearSpawn(ChunkPos pos) {
            int radius = BaseFinderMod.config.susChunks.ignoreSpawnRadius;
            return Math.abs(pos.x) <= radius/16 && Math.abs(pos.z) <= radius/16;
        }

        private boolean isKnownStructure(ScanResult result) {
            return result.hasVillage || result.hasMineshaft || result.hasStronghold ||
                   result.hasAncientCity || result.hasBastion || result.hasFortress;
        }

        private SusScore calculateSusScore(ChunkPos pos, ScanResult result) {
            Config.SignalWeights w = BaseFinderMod.config.signalWeights;

            float foreign = result.foreignBlockCount * w.foreignBlocks;
            float light = result.lightAnomalyCount * w.lightAnomalies;
            float geo = result.geometryScore * w.geometry;
            float be = result.blockEntityCount * w.blockEntities;
            float farm = result.farmScore * w.farms;
            float terrain = result.terrainEditScore * w.terrainEdits;
            float entity = result.entityClusterScore * w.entityClusters;
            float chunkCtx = (result.isOldGenSurrounded ? 1 : 0) * w.newChunkContext;

            float total = foreign + light + geo + be + farm + terrain + entity + chunkCtx;
            total = Math.min(100, total * 0.5f);

            String topSignal = getTopSignal(foreign, light, geo, be, farm, terrain, entity, chunkCtx);

            return new SusScore(total, foreign, light, geo, be, farm, terrain, entity, chunkCtx, topSignal);
        }

        private String getTopSignal(float... scores) {
            String[] names = {"Foreign Blocks", "Light Anomalies", "Geometry", "Block Entities",
                            "Farms", "Terrain Edits", "Entity Clusters", "Chunk Context"};
            int maxIdx = 0;
            for (int i = 1; i < scores.length; i++) {
                if (scores[i] > scores[maxIdx]) maxIdx = i;
            }
            return names[maxIdx];
        }

        public record SusScore(
            float total, float foreign, float light, float geo, float be,
            float farm, float terrain, float entity, float chunkCtx, String topSignal,
            ChunkPos pos
        ) {
            public SusScore(float total, float foreign, float light, float geo, float be,
                          float farm, float terrain, float entity, float chunkCtx, String topSignal) {
                this(total, foreign, light, geo, be, farm, terrain, entity, chunkCtx, topSignal, null);
            }
        }
    }
}