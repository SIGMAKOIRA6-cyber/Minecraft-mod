package com.basefinder.util;

import com.basefinder.BaseFinderMod;
import com.basefinder.config.Config;
import com.google.gson.*;
import net.minecraft.util.math.ChunkPos;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class WaypointManager {
    private final List<Waypoint> waypoints = new ArrayList<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public static class Waypoint {
        public String name;
        public int chunkX, chunkZ;
        public int dimension;
        public long timestamp;
        public float score;
        public String topSignal;

        public Waypoint() {}

        public Waypoint(String name, ChunkPos pos, int dimension, float score, String topSignal) {
            this.name = name;
            this.chunkX = pos.x;
            this.chunkZ = pos.z;
            this.dimension = dimension;
            this.timestamp = System.currentTimeMillis();
            this.score = score;
            this.topSignal = topSignal;
        }

        public ChunkPos getPos() {
            return new ChunkPos(chunkX, chunkZ);
        }

        public String getDisplayName() {
            return name + " (" + chunkX + ", " + chunkZ + ")";
        }
    }

    public void load() {
        try {
            if (Files.exists(Config.WAYPOINTS_FILE)) {
                String json = Files.readString(Config.WAYPOINTS_FILE);
                Waypoint[] loaded = gson.fromJson(json, Waypoint[].class);
                if (loaded != null) {
                    waypoints.clear();
                    waypoints.addAll(Arrays.asList(loaded));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void save() {
        try {
            Files.createDirectories(Config.CONFIG_DIR);
            Files.writeString(Config.WAYPOINTS_FILE, gson.toJson(waypoints));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void add(Waypoint wp) {
        if (waypoints.size() >= BaseFinderMod.config.waypoints.maxWaypoints) {
            waypoints.remove(0);
        }
        waypoints.add(wp);
        save();
    }

    public void remove(int index) {
        if (index >= 0 && index < waypoints.size()) {
            waypoints.remove(index);
            save();
        }
    }

    public List<Waypoint> getWaypoints() {
        return new ArrayList<>(waypoints);
    }

    public void clear() {
        waypoints.clear();
        save();
    }
}