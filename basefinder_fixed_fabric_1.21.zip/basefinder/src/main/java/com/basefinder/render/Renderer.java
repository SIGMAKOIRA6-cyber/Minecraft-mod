package com.basefinder.render;

import com.basefinder.BaseFinderMod;
import com.basefinder.config.Config;
import com.basefinder.modules.ModuleManager;
import com.basefinder.scan.ScanResult;
import com.basefinder.util.Vec3i;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

public class Renderer {
    private final MinecraftClient client = MinecraftClient.getInstance();
    private VertexBuffer chunkBuffer;
    private boolean bufferDirty = true;

    public void render(WorldRenderEvents.Context context) {
        if (client.world == null || client.player == null) return;

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider.Immediate vertexConsumers = client.getBufferBuilders().getEntityVertexConsumers();
        Vec3d cameraPos = context.camera().getPos();

        renderModules(matrices, vertexConsumers, cameraPos);
        renderHUD(matrices, cameraPos);

        vertexConsumers.draw();
    }

    private void renderModules(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, Vec3d cameraPos) {
        ModuleManager manager = BaseFinderMod.moduleManager;
        if (manager == null) return;

        Config.RenderSettings rs = BaseFinderMod.config.render;
        Config.Colors cs = BaseFinderMod.config.colors;

        for (var entry : manager.scanCache.entrySet()) {
            ChunkPos pos = entry.getKey();
            ScanResult result = entry.getValue();

            double cx = (pos.getStartX() + 8) - cameraPos.x;
            double cz = (pos.getStartZ() + 8) - cameraPos.z;
            double dist = Math.sqrt(cx * cx + cz * cz);

            if (dist > BaseFinderMod.config.susChunks.renderDistance) continue;

            matrices.push();
            matrices.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);

            if (BaseFinderMod.config.newChunks.enabled) {
                renderNewChunks(matrices, consumers, pos, result);
            }
            if (BaseFinderMod.config.storageESP.enabled) {
                renderStorageESP(matrices, consumers, pos, result);
            }
            if (BaseFinderMod.config.baseScore.enabled) {
                renderBaseScore(matrices, consumers, pos, result);
            }
            if (BaseFinderMod.config.tunnelDetector.enabled) {
                renderTunnels(matrices, consumers, pos, result);
            }
            if (BaseFinderMod.config.susChunks.enabled) {
                renderSusChunks(matrices, consumers, pos, result, rs, cs);
            }

            matrices.pop();
        }
    }

    private void renderNewChunks(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, ScanResult result) {
        ModuleManager.NewChunksModule.ChunkState state = BaseFinderMod.moduleManager.newChunks.getState(pos);
        if (state == null) return;

        Config.NewChunks nc = BaseFinderMod.config.newChunks;
        int color = state.isOldGeneration ? nc.oldGenColor : nc.newGenColor;

        renderChunkOutline(matrices, consumers, pos, color, nc.outlineWidth, nc.outlineAlpha);
    }

    private void renderStorageESP(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, ScanResult result) {
        List<ModuleManager.StorageESPModule.StorageInfo> storages = BaseFinderMod.moduleManager.storageESP.getStorages(pos);
        if (storages == null) return;

        Config.StorageESP se = BaseFinderMod.config.storageESP;
        BlockPos playerPos = client.player.getBlockPos();

        for (ModuleManager.StorageESPModule.StorageInfo info : storages) {
            double dx = info.pos.getX() - client.player.getX();
            double dy = info.pos.getY() - client.player.getY();
            double dz = info.pos.getZ() - client.player.getZ();
            double dist = Math.sqrt(dx*dx + dy*dy + dz*dz);

            if (dist > se.maxDistance) continue;

            int color = se.colors.getOrDefault(info.type.name().toLowerCase(), 0xFFFFFFFF);

            matrices.push();
            matrices.translate(info.pos.getX(), info.pos.getY(), info.pos.getZ());

            renderBox(matrices, consumers, 0.5f, color, se.boxWidth, se.boxAlpha);

            if (se.showTracers) {
                renderTracer(matrices, consumers, new Vec3d(dx, dy, dz), color);
            }

            matrices.pop();
        }
    }

    private void renderBaseScore(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, ScanResult result) {
        ModuleManager.BaseScoreModule.BaseScore score = BaseFinderMod.moduleManager.baseScore.getScore(pos);
        if (score == null) return;

        matrices.push();
        matrices.translate(pos.getStartX() + 8, maxY(result) + 2, pos.getStartZ() + 8);

        int color = getScoreColor(score.score);
        renderChunkColumn(matrices, consumers, pos, color);

        if (BaseFinderMod.config.render.showScores) {
            renderScoreText(matrices, score.score, score.topSignals);
        }

        matrices.pop();
    }

    private void renderTunnels(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, ScanResult result) {
        List<ModuleManager.TunnelDetectorModule.Tunnel> tunnels = BaseFinderMod.moduleManager.tunnelDetector.getTunnels(pos);
        if (tunnels == null) return;

        Config.TunnelDetector td = BaseFinderMod.config.tunnelDetector;

        for (ModuleManager.TunnelDetectorModule.Tunnel tunnel : tunnels) {
            matrices.push();
            matrices.translate(tunnel.start.getX(), tunnel.start.getY(), tunnel.start.getZ());

            Vec3d end = new Vec3d(tunnel.end.getX() - tunnel.start.getX(),
                                   tunnel.end.getY() - tunnel.start.getY(),
                                   tunnel.end.getZ() - tunnel.start.getZ());

            renderLine(matrices, consumers, Vec3d.ZERO, end, td.highlightColor, 2, 1.0f);

            matrices.pop();
        }
    }

    private void renderSusChunks(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, ScanResult result,
                                 Config.RenderSettings rs, Config.Colors cs) {
        ModuleManager.SusChunksModule.SusScore score = BaseFinderMod.moduleManager.susChunks.getSusScore(pos);
        if (score == null) return;

        int color = getSusColor(score.total, cs);

        if (BaseFinderMod.config.susChunks.heatMapMode) {
            renderChunkColumn(matrices, consumers, pos, color, rs.columnAlpha * 2);
        } else {
            renderChunkColumn(matrices, consumers, pos, color, rs.columnAlpha);
            renderChunkOutline(matrices, consumers, pos, color, rs.outlineWidth, rs.outlineAlpha);

            if (BaseFinderMod.config.render.showScores) {
                matrices.push();
                matrices.translate(pos.getStartX() + 8, maxY(result) + 3, pos.getStartZ() + 8);
                renderScoreText(matrices, (int)score.total, List.of(score.topSignal));
                matrices.pop();
            }
        }
    }

    private void renderChunkColumn(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, int color, float alpha) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f * alpha;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getTranslucent());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        int x1 = pos.getStartX();
        int z1 = pos.getStartZ();
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        int y1 = BaseFinderMod.config.general.minY;
        int y2 = BaseFinderMod.config.general.maxY;

        vc.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y1, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y2, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y2, z1).color(r, g, b, a).next();

        vc.vertex(matrix, x1, y1, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y1, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y2, z2).color(r, g, b, a).next();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void renderChunkOutline(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, ChunkPos pos, int color, int width, float alpha) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f * alpha;

        RenderSystem.lineWidth(width);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        int x1 = pos.getStartX();
        int z1 = pos.getStartZ();
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        int y1 = BaseFinderMod.config.general.minY;
        int y2 = BaseFinderMod.config.general.maxY;

        vc.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y1, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y1, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y1, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();

        vc.vertex(matrix, x1, y2, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y2, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y2, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y2, z1).color(r, g, b, a).next();

        vc.vertex(matrix, x1, y1, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y2, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y1, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y2, z1).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y1, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x2, y2, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y1, z2).color(r, g, b, a).next();
        vc.vertex(matrix, x1, y2, z2).color(r, g, b, a).next();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1);
    }

    private void renderBox(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, float size, int color, int width, float alpha) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f * alpha;

        RenderSystem.lineWidth(width);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        float min = -size, max = size;

        vc.vertex(matrix, min, min, min).color(r, g, b, a).next();
        vc.vertex(matrix, max, min, min).color(r, g, b, a).next();
        vc.vertex(matrix, max, max, min).color(r, g, b, a).next();
        vc.vertex(matrix, min, max, min).color(r, g, b, a).next();
        vc.vertex(matrix, min, min, min).color(r, g, b, a).next();

        vc.vertex(matrix, min, min, max).color(r, g, b, a).next();
        vc.vertex(matrix, max, min, max).color(r, g, b, a).next();
        vc.vertex(matrix, max, max, max).color(r, g, b, a).next();
        vc.vertex(matrix, min, max, max).color(r, g, b, a).next();
        vc.vertex(matrix, min, min, max).color(r, g, b, a).next();

        vc.vertex(matrix, min, min, min).color(r, g, b, a).next();
        vc.vertex(matrix, min, min, max).color(r, g, b, a).next();
        vc.vertex(matrix, max, min, min).color(r, g, b, a).next();
        vc.vertex(matrix, max, min, max).color(r, g, b, a).next();
        vc.vertex(matrix, max, max, min).color(r, g, b, a).next();
        vc.vertex(matrix, max, max, max).color(r, g, b, a).next();
        vc.vertex(matrix, min, max, min).color(r, g, b, a).next();
        vc.vertex(matrix, min, max, max).color(r, g, b, a).next();

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1);
    }

    private void renderTracer(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, Vec3d dir, int color) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = 0.5f;

        RenderSystem.lineWidth(1);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        vc.vertex(matrix, 0, 0, 0).color(r, g, b, a).next();
        vc.vertex(matrix, dir.x, dir.y, dir.z).color(r, g, b, a).next();

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void renderLine(MatrixStack matrices, VertexConsumerProvider.Immediate consumers, Vec3d start, Vec3d end, int color, int width, float alpha) {
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;
        float a = ((color >> 24) & 0xFF) / 255f * alpha;

        RenderSystem.lineWidth(width);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();

        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        vc.vertex(matrix, start.x, start.y, start.z).color(r, g, b, a).next();
        vc.vertex(matrix, end.x, end.y, end.z).color(r, g, b, a).next();

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.lineWidth(1);
    }

    private void renderScoreText(MatrixStack matrices, int score, List<String> signals) {
        TextRenderer tr = client.textRenderer;
        String text = "§l" + score + "§r";
        if (!signals.isEmpty()) text += " §7(" + signals.get(0) + ")§r";

        float scale = 0.025f;
        matrices.scale(scale, -scale, scale);
        matrices.translate(-tr.getWidth(text) / 2f, 0, 0);

        tr.drawWithShadow(matrices, text, 0, 0, 0xFFFFFF);
    }

    private int getScoreColor(int score) {
        Config.Colors cs = BaseFinderMod.config.colors;
        if (score >= 80) return cs.red;
        if (score >= 60) return cs.orange;
        if (score >= 30) return cs.yellow;
        return cs.green;
    }

    private int getSusColor(float score, Config.Colors cs) {
        if (score >= 80) return cs.red;
        if (score >= 60) return cs.orange;
        if (score >= 30) return cs.yellow;
        return cs.green;
    }

    private int maxY(ScanResult result) {
        return Math.max(result.maxY, BaseFinderMod.config.general.maxY);
    }

    private void renderHUD(MatrixStack matrices, Vec3d cameraPos) {
        if (!BaseFinderMod.config.waypoints.enabled) return;

        Config.Waypoints wp = BaseFinderMod.config.waypoints;
        TextRenderer tr = client.textRenderer;

        matrices.push();
        matrices.translate(wp.hudX, wp.hudY, 0);

        List<ModuleManager.SusChunksModule.SusScore> topSus = BaseFinderMod.moduleManager.susChunks.getTopSus(10);
        int y = 0;

        for (ModuleManager.SusChunksModule.SusScore score : topSus) {
            if (score.pos == null) continue;

            double dx = (score.pos.getStartX() + 8) - cameraPos.x;
            double dz = (score.pos.getStartZ() + 8) - cameraPos.z;
            double dist = Math.sqrt(dx*dx + dz*dz);
            double angle = Math.toDegrees(Math.atan2(dz, dx)) - client.player.getYaw();
            angle = MathHelper.wrapDegrees((float)angle);

            String arrow = getDirectionArrow(angle);
            String text = String.format("§l%s §7[%.0fm] §8%s §7(%.0f) §r%s",
                score.pos.toString(), dist, score.topSignal, score.total, arrow);

            tr.drawWithShadow(matrices, text, 0, y, 0xFFFFFF);
            y += 12;
        }

        matrices.pop();
    }

    private String getDirectionArrow(double angle) {
        if (angle >= -22.5 && angle < 22.5) return "→";
        if (angle >= 22.5 && angle < 67.5) return "↘";
        if (angle >= 67.5 && angle < 112.5) return "↓";
        if (angle >= 112.5 && angle < 157.5) return "↙";
        if (angle >= 157.5 || angle < -157.5) return "←";
        if (angle >= -157.5 && angle < -112.5) return "↖";
        if (angle >= -112.5 && angle < -67.5) return "↑";
        return "↗";
    }
}