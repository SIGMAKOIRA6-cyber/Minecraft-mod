package com.basefinder.config;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Config {
    public static final Path CONFIG_DIR = FabricLoader.getInstance().getConfigDir().resolve("basefinder");
    public static final Path CONFIG_FILE = CONFIG_DIR.resolve("config.json");
    public static final Path WAYPOINTS_FILE = CONFIG_DIR.resolve("waypoints.json");

    public General general = new General();
    public NewChunks newChunks = new NewChunks();
    public StorageESP storageESP = new StorageESP();
    public BaseScore baseScore = new BaseScore();
    public TunnelDetector tunnelDetector = new TunnelDetector();
    public Waypoints waypoints = new Waypoints();
    public SusChunks susChunks = new SusChunks();
    public SignalWeights signalWeights = new SignalWeights();
    public RenderSettings render = new RenderSettings();
    public Colors colors = new Colors();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Config load() {
        try {
            Files.createDirectories(CONFIG_DIR);
            if (Files.exists(CONFIG_FILE)) {
                String json = Files.readString(CONFIG_FILE);
                return GSON.fromJson(json, Config.class);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Config();
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_DIR);
            Files.writeString(CONFIG_FILE, GSON.toJson(this));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static class General {
        public boolean enabled = true;
        public int scanRange = 8;
        public int minY = -64;
        public int maxY = 320;
        public int sampleRate = 4;
        public int scanBudgetMs = 2;
        public int keybind = 61;
    }

    public static class NewChunks {
        public boolean enabled = true;
        public int outlineWidth = 2;
        public float outlineAlpha = 0.6f;
        public int oldGenColor = 0xFF00FF00;
        public int newGenColor = 0xFFFF0000;
    }

    public static class StorageESP {
        public boolean enabled = true;
        public int maxDistance = 128;
        public boolean showTracers = true;
        public int boxWidth = 1;
        public float boxAlpha = 0.4f;
        public Map<String, Integer> colors = new LinkedHashMap<>(Map.of(
            "chest", 0xFFFFD700,
            "barrel", 0xFF8B4513,
            "shulker", 0xFF9370DB,
            "furnace", 0xFFB22222,
            "hopper", 0xFF696969,
            "spawner", 0xFFFF00FF
        ));
    }

    public static class BaseScore {
        public boolean enabled = true;
        public int threshold = 50;
        public int topCount = 10;
        public int minNonNaturalRatio = 5;
    }

    public static class TunnelDetector {
        public boolean enabled = true;
        public int minLength = 20;
        public boolean detectIceRoads = true;
        public boolean detectHighways = true;
        public int highlightColor = 0xFF00FFFF;
    }

    public static class Waypoints {
        public boolean enabled = true;
        public boolean autoSave = true;
        public int hudX = 10;
        public int hudY = 10;
        public int maxWaypoints = 100;
    }

    public static class SusChunks {
        public boolean enabled = true;
        public int threshold = 40;
        public int renderDistance = 128;
        public boolean heatMapMode = false;
        public int ignoreSpawnRadius = 200;
    }

    public static class SignalWeights {
        public float foreignBlocks = 1.0f;
        public float lightAnomalies = 1.2f;
        public float geometry = 1.5f;
        public float blockEntities = 2.0f;
        public float farms = 1.3f;
        public float terrainEdits = 1.4f;
        public float entityClusters = 1.1f;
        public float newChunkContext = 1.8f;
    }

    public static class RenderSettings {
        public int chunkColumnHeight = 256;
        public float columnAlpha = 0.15f;
        public float outlineAlpha = 0.8f;
        public int outlineWidth = 2;
        public boolean showScores = true;
        public boolean showSignalNames = true;
    }

    public static class Colors {
        public int green = 0xFF00FF00;
        public int yellow = 0xFFFFFF00;
        public int orange = 0xFFFFA500;
        public int red = 0xFFFF0000;
        public int heatmapLow = 0xFF00FF00;
        public int heatmapHigh = 0xFFFF0000;
    }
}