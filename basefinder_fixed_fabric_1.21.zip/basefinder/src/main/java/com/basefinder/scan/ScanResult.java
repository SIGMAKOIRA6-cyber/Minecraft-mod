package com.basefinder.scan;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ScanResult {
    public ChunkPos chunkPos;
    public int minY, maxY;
    public final Map<BlockPos, BlockState> blockStates = new ConcurrentHashMap<>();
    public final Map<BlockPos, BlockEntity> blockEntities = new ConcurrentHashMap<>();

    public int foreignBlockCount = 0;
    public int lightAnomalyCount = 0;
    public float geometryScore = 0;
    public int nonNaturalCount = 0;
    public float terrainEditScore = 0;
    public int blockEntityCount = 0;
    public float farmScore = 0;
    public float entityClusterScore = 0;
    public boolean isOldGenSurrounded = false;

    public boolean hasStorage = false;
    public boolean hasBeds = false;
    public boolean hasSigns = false;
    public boolean hasRedstone = false;
    public boolean hasVillage = false;
    public boolean hasMineshaft = false;
    public boolean hasStronghold = false;
    public boolean hasAncientCity = false;
    public boolean hasBastion = false;
    public boolean hasFortress = false;

    public int totalBlocksScanned = 0;
    public long timestamp = System.currentTimeMillis();

    public float nonNaturalRatio = 0;

    public void finalize() {
        if (totalBlocksScanned > 0) {
            nonNaturalRatio = (nonNaturalCount * 100f) / totalBlocksScanned;
        }
        detectStructures();
    }

    private void detectStructures() {
        int villagerBlocks = 0, mineshaftBlocks = 0, strongholdBlocks = 0;
        int ancientCityBlocks = 0, bastionBlocks = 0, fortressBlocks = 0;

        for (BlockState state : blockStates.values()) {
            Block block = state.getBlock();
            String name = block.getName().getString();

            if (name.contains("villager") || name.contains("bell") || name.contains("composter") ||
                name.contains("lectern") || name.contains("loom") || name.contains("cartography") ||
                name.contains("smithing") || name.contains("grindstone") || name.contains("stonecutter")) {
                villagerBlocks++;
            }
            if (name.contains("fence") && (name.contains("oak") || name.contains("spruce")) &&
                (name.contains("rail") || name.contains("torch"))) {
                mineshaftBlocks++;
            }
            if (name.contains("stone_brick") || name.contains("mossy_stone_brick") ||
                name.contains("cracked_stone_brick") || name.contains("chiseled_stone_brick")) {
                strongholdBlocks++;
            }
            if (name.contains("sculk") || name.contains("reinforced_deepslate") ||
                name.contains("candle") || name.contains("echo_shard")) {
                ancientCityBlocks++;
            }
            if (name.contains("basalt") || name.contains("blackstone") ||
                name.contains("nether_brick") || name.contains("gold_block") ||
                name.contains("gilded_blackstone")) {
                bastionBlocks++;
            }
            if (name.contains("nether_brick") && (name.contains("fence") || name.contains("stairs")) ||
                name.contains("blaze_spawner") || name.contains("wither_skeleton")) {
                fortressBlocks++;
            }
        }

        hasVillage = villagerBlocks > 10;
        hasMineshaft = mineshaftBlocks > 15;
        hasStronghold = strongholdBlocks > 20;
        hasAncientCity = ancientCityBlocks > 5;
        hasBastion = bastionBlocks > 15;
        hasFortress = fortressBlocks > 10;
    }

    public boolean isStale() {
        return System.currentTimeMillis() - timestamp > 30000;
    }
}