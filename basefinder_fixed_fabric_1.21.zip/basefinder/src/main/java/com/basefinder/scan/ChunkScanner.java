package com.basefinder.scan;

import com.basefinder.BaseFinderMod;
import com.basefinder.modules.ModuleManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import java.util.*;
import java.util.concurrent.*;

public class ChunkScanner {
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "BaseFinder-Scanner");
        t.setDaemon(true);
        return t;
    });

    private final Queue<ChunkPos> scanQueue = new ConcurrentLinkedQueue<>();
    private final Set<ChunkPos> queuedChunks = ConcurrentHashMap.newKeySet();
    private long lastScanTime = 0;
    private int scannedThisTick = 0;

    public void onTick() {
        if (System.currentTimeMillis() - lastScanTime < 50) return;

        MinecraftClient client = BaseFinderMod.getClient();
        if (client.world == null || client.player == null) return;

        ChunkPos playerChunk = client.player.getChunkPos();
        int range = BaseFinderMod.config.general.scanRange;

        for (int dx = -range; dx <= range; dx++) {
            for (int dz = -range; dz <= range; dz++) {
                ChunkPos pos = new ChunkPos(playerChunk.x + dx, playerChunk.z + dz);
                if (!queuedChunks.contains(pos)) {
                    scanQueue.add(pos);
                    queuedChunks.add(pos);
                }
            }
        }

        long budgetNs = BaseFinderMod.config.general.scanBudgetMs * 1_000_000L;
        long start = System.nanoTime();
        scannedThisTick = 0;

        while (!scanQueue.isEmpty() && System.nanoTime() - start < budgetNs) {
            ChunkPos pos = scanQueue.poll();
            if (pos == null) break;
            queuedChunks.remove(pos);
            scanChunkAsync(pos);
            scannedThisTick++;
        }

        lastScanTime = System.currentTimeMillis();
    }

    private void scanChunkAsync(ChunkPos pos) {
        executor.submit(() -> {
            MinecraftClient client = BaseFinderMod.getClient();
            if (client.world == null) return;

            Chunk chunk = client.world.getChunk(pos.x, pos.z);
            if (chunk == null) return;

            ScanResult result = scanChunk(chunk);
            ModuleManager manager = BaseFinderMod.moduleManager;
            if (manager != null) {
                manager.putScanResult(pos, result);
            }
        });
    }

    private ScanResult scanChunk(Chunk chunk) {
        ScanResult result = new ScanResult();
        result.chunkPos = chunk.getPos();
        result.minY = BaseFinderMod.config.general.minY;
        result.maxY = BaseFinderMod.config.general.maxY;
        int sample = BaseFinderMod.config.general.sampleRate;

        WorldChunk wc = (WorldChunk) chunk;
        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();

        for (int x = 0; x < 16; x += sample) {
            for (int z = 0; z < 16; z += sample) {
                for (int y = result.minY; y <= result.maxY; y += sample) {
                    BlockPos pos = new BlockPos(startX + x, y, startZ + z);
                    BlockState state = chunk.getBlockState(pos);
                    result.blockStates.put(pos.toImmutable(), state);
                    analyzeBlock(result, pos, state);
                }
            }
        }

        for (BlockEntity be : chunk.getBlockEntities().values()) {
            result.blockEntities.put(be.getPos().toImmutable(), be);
            analyzeBlockEntity(result, be);
        }

        result.finalize();
        return result;
    }

    private void analyzeBlock(ScanResult result, BlockPos pos, BlockState state) {
        Block block = state.getBlock();

        if (isForeignBlock(block, pos)) result.foreignBlockCount++;
        if (isLightAnomaly(block, state, pos)) result.lightAnomalyCount++;
        if (isGeometryAnomaly(block, state, pos)) result.geometryScore += 0.5f;
        if (isPlayerPlacedBlock(block)) result.nonNaturalCount++;
        if (isTerrainEdit(block, state, pos)) result.terrainEditScore += 0.3f;
        result.totalBlocksScanned++;
    }

    private void analyzeBlockEntity(ScanResult result, BlockEntity be) {
        result.blockEntityCount++;
        BlockEntityType<?> type = be.getType();

        if (type == BlockEntityType.CHEST || type == BlockEntityType.BARREL ||
            type == BlockEntityType.SHULKER_BOX || type == BlockEntityType.FURNACE ||
            type == BlockEntityType.HOPPER || type == BlockEntityType.MOB_SPAWNER) {
            result.hasStorage = true;
        }
        if (type == BlockEntityType.BED) result.hasBeds = true;
        if (type == BlockEntityType.SIGN || type == BlockEntityType.BANNER) result.hasSigns = true;
        if (type == BlockEntityType.COMMAND_BLOCK) result.hasRedstone = true;
    }

    private boolean isForeignBlock(Block block, BlockPos pos) {
        String dim = BaseFinderMod.getClient().world.getDimension().getType().getName().getPath();
        boolean overworld = dim.equals("overworld");
        boolean nether = dim.equals("the_nether");
        boolean end = dim.equals("the_end");

        if (overworld) {
            return block == Blocks.NETHERRACK || block == Blocks.COBBLESTONE ||
                   block.getName().getString().contains("planks") ||
                   block == Blocks.GLASS || block.getName().getString().contains("concrete") ||
                   block.getName().getString().contains("wool") || block == Blocks.OBSIDIAN;
        } else if (nether) {
            return block == Blocks.COBBLESTONE || block == Blocks.STONE_BRICKS ||
                   block == Blocks.DIRT || block == Blocks.GRASS_BLOCK;
        } else if (end) {
            return block != Blocks.END_STONE && block != Blocks.END_STONE_BRICKS &&
                   block != Blocks.PURPUR_BLOCK && block != Blocks.OBSIDIAN &&
                   block != Blocks.BEDROCK;
        }
        return false;
    }

    private boolean isLightAnomaly(Block block, BlockState state, BlockPos pos) {
        if (block == Blocks.TORCH || block == Blocks.WALL_TORCH ||
            block == Blocks.LANTERN || block == Blocks.SOUL_LANTERN ||
            block == Blocks.GLOWSTONE || block == Blocks.SEA_LANTERN ||
            block == Blocks.SHROOMLIGHT || block == Blocks.REDSTONE_LAMP) {
            return true;
        }
        return state.getLuminance() > 0 && !isNaturalLightSource(block);
    }

    private boolean isNaturalLightSource(Block block) {
        return block == Blocks.GLOWSTONE || block == Blocks.SEA_LANTERN ||
               block == Blocks.SHROOMLIGHT || block == Blocks.LAVA;
    }

    private boolean isGeometryAnomaly(Block block, BlockState state, BlockPos pos) {
        String name = block.getName().getString();
        return name.contains("stair") || name.contains("slab") ||
               block == Blocks.COBBLESTONE_WALL || block == Blocks.STONE_BRICK_WALL;
    }

    private boolean isPlayerPlacedBlock(Block block) {
        return block == Blocks.COBBLESTONE || block == Blocks.STONE_BRICKS ||
               block.getName().getString().contains("planks") ||
               block == Blocks.GLASS || block.getName().getString().contains("concrete") ||
               block.getName().getString().contains("wool") || block == Blocks.OBSIDIAN ||
               block == Blocks.BRICKS || block == Blocks.NETHER_BRICKS ||
               block == Blocks.QUARTZ_BLOCK || block == Blocks.END_STONE_BRICKS;
    }

    private boolean isTerrainEdit(Block block, BlockState state, BlockPos pos) {
        return block == Blocks.LAVA || block == Blocks.WATER ||
               block == Blocks.SAND || block == Blocks.GRAVEL ||
               block.getName().getString().contains("log") && pos.getY() > 100;
    }

    public void shutdown() {
        executor.shutdown();
    }
}