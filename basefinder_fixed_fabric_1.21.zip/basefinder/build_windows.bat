@echo off
where gradle >nul 2>nul
if errorlevel 1 (echo Gradle was not found. Install Gradle 8.8+ and Java 21, then run this again.& pause & exit /b 1)
gradle build
echo.
echo JAR: build\libs\basefinder-1.0.0.jar
pause
