plugins {
    id("fabric-loom") version "1.6.1"
    id("java")
}

group = "com.basefinder"
version = "1.0.0"
java.toolchain.languageVersion.set(JavaLanguageVersion.of(21))

repositories {
    mavenCentral()
    maven("https://maven.fabricmc.net/")
    maven("https://maven.terraformersmc.com/")
}

dependencies {
    minecraft("com.mojang:minecraft:1.21")
    mappings("net.fabricmc:yarn:1.21+build.1:v2")
    modImplementation("net.fabricmc:fabric-loader:0.16.9")
    modImplementation("net.fabricmc:fabric-api:0.108.0+1.21")
    modImplementation("com.terraformersmc:modmenu:11.0.5")
}

loom {
    mappings.set("yarn:1.21+build.1:v2")
    modId.set("basefinder")
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.compilerArgs << "-Xlint:unchecked" << "-Xlint:deprecation"
}

tasks.named<Jar>("jar") {
    manifest {
        attributes(
            "Fabric-Mod" to "true",
            "Mod-Id" to "basefinder",
            "Mod-Name" to "BaseFinder",
            "Mod-Version" to project.version.toString(),
            "Main-Class" to "com.basefinder.BaseFinderMod"
        )
    }
}