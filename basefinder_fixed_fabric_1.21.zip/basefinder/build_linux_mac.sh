#!/usr/bin/env bash
set -e
gradle build
printf "\nJAR: build/libs/basefinder-1.0.0.jar\n"
