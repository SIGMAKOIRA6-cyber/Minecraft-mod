# BaseFinder

A Fabric 1.21 client-side Minecraft mod for locating player bases using only data the server sends to the client.

## Features

### 1. NewChunks
Detects chunks that arrive with old-generation vs freshly generated state using fluid flow direction and chunk load packet heuristics. Renders outlines to reveal trails of player-explored terrain.

### 2. StorageESP
Highlights chests, barrels, shulkers, furnaces, hoppers, and spawners in loaded chunks with box outlines and tracers. Color-coded per type.

### 3. BaseScore
Scores chunks based on density of player-placed blocks (non-natural blocks, storage, beds, signs, redstone components). Flags chunks above a configurable threshold and lists the top 10 with coordinates.

### 4. Tunnel Detector
Finds long straight 1x2 or 2x2 tunnels, ice roads, and nether highways in loaded chunks.

### 5. Waypoints
Auto-saves flagged locations, persists to JSON, shows a HUD list with distance and direction.

### 6. SusChunks
Flags suspicious chunks by combining multiple weak signals into one score:
- Foreign blocks (blocks that don't belong in the dimension/biome)
- Light anomalies (unnatural light sources underground)
- Geometry anomalies (flat floors, straight tunnels, right angles)
- Block entities (storage, beds, signs, etc.)
- Farms (uniform crop areas, hopper systems, redstone clusters)
- Terrain edits (straight edges, bedrock tunnels, placed fluids)
- Entity clusters (minecarts, animal pens, villager setups)
- NewChunk context (old-gen chunk surrounded by fresh chunks)

## Controls

- **Right Shift**: Open config GUI
- **B**: Toggle mod on/off

## Configuration

All settings are configurable through the GUI (Right Shift) and persisted to `config/basefinder/config.json`.

## Building

Requirements: Java 21 and Gradle 8.8 or newer.

From the project folder run:

```bash
gradle build
```

On Windows you can run `build_windows.bat`. On Linux/macOS you can run `./build_linux_mac.sh`.

The output JAR will be in `build/libs/`.

### Installing the mod

1. Use Minecraft Java Edition 1.21 with Fabric Loader.
2. Install Fabric API 0.108.0+1.21.
3. Put the generated `basefinder-1.0.0.jar` in `.minecraft/mods/`.
4. Mod Menu is used for the config screen; install a Minecraft 1.21-compatible Mod Menu if you want the Mod Menu integration.


## Requirements

- Fabric Loader 0.16.9+
- Minecraft 1.21
- Fabric API 0.108.0+
- Java 21